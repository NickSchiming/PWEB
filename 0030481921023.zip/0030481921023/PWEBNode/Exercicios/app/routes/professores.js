module.exports = function(app) {
    app.get('/informacao/professores', function(req, res) {
        const sql = require('mssql/msnodesqlv8');
        const sqlConfig = { user: 'BD1921023', password: 'OkCOmputer4512', database: 'BD', server: '192.168.1.6', }
        async function getProfessores() {
            try {
                const pool = await sql.connect(sqlConfig);
                const results = await pool.request().query('SELECT * from PROFESSORES');
                res.render('informacao/professores', { profs: results.recordset });
            } catch (err) { console.log(err) }
        }
        const professores = getProfessores();
    });
}